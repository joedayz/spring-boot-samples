package com.example.cfp.web;

public enum Section {
	HOME, SUBMIT, NEWS, ADMIN
}